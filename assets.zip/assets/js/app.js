// let x = 1
// let matrix = [x, x, x, x, x, x, x, x,
//   x, x, x, x, x, x, x, x,
//   x, x, x, x, x, x, x, x,
//   x, x, x, x, x, x, x, x,
//   x, x, x, x, x, x, x, x,
//   x, x, x, x, x, x, x, x,
//   x, x, x, x, x, x, x, x,
//   x, x, x, x, x, x, x, x
// ]

(function () {

  var app = {
    init: function () {
      console.log("Initilazing application");
      // Initialize Firebase
      this.config = {
        apiKey: "AIzaSyDaXCXy2Rc7rgL4Yq7mO_wJUL_pwZwVRnw",
        authDomain: "wot-1819-jerobern.firebaseapp.com",
        databaseURL: "https://wot-1819-jerobern.firebaseio.com",
        projectId: "wot-1819-jerobern",
        storageBucket: "wot-1819-jerobern.appspot.com",
        messagingSenderId: "196745075521"
      };
      firebase.initializeApp(this.config);
      let database = firebase.database();

      this.row = 8;
      this.col = 8;
      this.size = 40;
      this.blue = "(0, 0, 255)"
      this.black = "(0, 0, 0)"

      // Cache Div Element
      this.ledContainerElement = document.querySelector('.ledContainer');

      this.createCharacterArcadeMatrix(this.row, this.col);
    },

    createCharacterArcadeMatrix: function (row, col) {
      let pattern = '';
      let led = '';

      // Generate bit-string
      for (i = 0; i < row; i++) {
        let tempStr = '';
        for (j = 0; j < col / 2; j++) {
          // Randomly generate 1 or 0
          tempStr += Math.round(Math.random());
        }
        // Add tempStr + reversre tempStr to pattern
        pattern += tempStr + tempStr.split("").reverse().join("");
      }
      let matrix = [];
      for (i = 0; i < 64; i++) {
        let bit = parseInt(pattern.charAt(i));
        matrix.push()
      }

      // Render LEDs
      for (i = 0; i < row; i++) {
        for (j = 0; j < col; j++) {
          let bit = pattern.charAt((i * this.row) + j);
          let ledClass = (bit == 1) ? 'led--on' : 'led--off';
          let top = i * this.size;
          let left = j * this.size;
          led += `<div style="top:${top}px; left:${left}px; width:${this.size}px; height:${this.size}px" class="led ${ledClass}"></div>`;
          this.ledContainerElement.innerHTML = led;
        }
      }

      firebase.database().ref('current_character').set(pattern);

    }
  }
  app.init();
})();